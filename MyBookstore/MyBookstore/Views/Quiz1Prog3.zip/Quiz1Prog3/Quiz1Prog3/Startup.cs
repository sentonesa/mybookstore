﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Quiz1Prog3.Startup))]
namespace Quiz1Prog3
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
